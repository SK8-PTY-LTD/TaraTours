<?php

/*
* Title                   : Booking System PRO (WordPress Plugin)
* Version                 : 2.0
* File                    : views/search/views-backend-search-view.php
* File Version            : 1.0
* Created / Last Modified : 19 October 2014
* Author                  : Dot on Paper
* Copyright               : © 2012 Dot on Paper
* Website                 : http://www.dotonpaper.net
* Description             : Booking System PRO back end search view views class.
*/

    if (!class_exists('DOPBSPViewsFrontEndSearchView')){
        class DOPBSPViewsFrontEndSearchView extends DOPBSPViewsFrontEndSearch{
            /*
             * Constructor
             */
            function DOPBSPViewsFrontEndSearchView(){
            }
            
            /*
             * Returns search view.
             * 
             * @param args (array): function arguments
             *                      * atts (object): shortcode attributes
             *                      * settings (object): search settings
             * 
             * @return search view HTML
             */
            function template($args = array()){
                global $DOPBSP;
                
                $atts = $args['atts'];
                $settings = $args['settings'];
                
                $id = $atts['id'];
                
                $html = array();
                
                array_push($html, '<input type="hidden" name="DOPBSPSearch-view'.$id.'" id="DOPBSPSearch-view'.$id.'" value="'.$settings->view_default.'" />');
                
                if ($settings->view_list_enabled == 'true'
                        || $settings->view_grid_enabled == 'true'
                        || $settings->view_map_enabled == 'true'){
                    array_push($html, '<ul class="DOPBSPSearch-view">');

                    if  ($settings->view_list_enabled == 'true'){
                        array_push($html, ' <li id="DOPBSPSearch-view-list'.$id.'" class="dopbsp-view-list'.($settings->view_default == 'list' ? ' dopbsp-selected':'').'">');
                        array_push($html, '     <span class="dopbsp-info">'.$DOPBSP->text('SEARCH_FRONT_END_VIEW_LIST').'</span>');
                        array_push($html, ' </li>');
                    }

                    if  ($settings->view_grid_enabled == 'true'){
                        array_push($html, ' <li id="DOPBSPSearch-view-grid'.$id.'" class="dopbsp-view-grid'.($settings->view_default == 'grid' ? ' dopbsp-selected':'').'">');
                        array_push($html, '     <span class="dopbsp-info">'.$DOPBSP->text('SEARCH_FRONT_END_VIEW_GRID').'</span>');
                        array_push($html, ' </li>');
                    }

                    if  ($settings->view_map_enabled == 'true'){
                        array_push($html, ' <li id="DOPBSPSearch-view-map'.$id.'" class="dopbsp-view-map'.($settings->view_default == 'map' ? ' dopbsp-selected':'').'">');
                        array_push($html, '     <span class="dopbsp-info">'.$DOPBSP->text('SEARCH_FRONT_END_VIEW_MAP').'</span>');
                        array_push($html, ' </li>');
                    }
                    array_push($html, '</ul>');
                }
                
                return implode('', $html);
            }
        }
    }