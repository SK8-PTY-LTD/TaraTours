<?php

/*
* Title                   : Booking System PRO (WordPress Plugin)
* Version                 : 2.0
* File                    : includes/translation/class-translation-text-search.php
* File Version            : 1.0.8
* Created / Last Modified : 20 October 2014
* Author                  : Dot on Paper
* Copyright               : © 2012 Dot on Paper
* Website                 : http://www.dotonpaper.net
* Description             : Booking System PRO search translation text PHP class.
*/

    if (!class_exists('DOPBSPTranslationTextSearch')){
        class DOPBSPTranslationTextSearch{
            /*
             * Constructor
             */
            function DOPBSPTranslationTextSearch(){
                /*
                 * Initialize search text.
                 */
                add_filter('dopbsp_filter_translation', array(&$this, 'searches'));
                
                add_filter('dopbsp_filter_translation', array(&$this, 'searchesSearch'));
                
                add_filter('dopbsp_filter_translation', array(&$this, 'searchesAddSearch'));
                add_filter('dopbsp_filter_translation', array(&$this, 'searchesEditSearch'));
                add_filter('dopbsp_filter_translation', array(&$this, 'searchesDeleteSearch'));
                
                add_filter('dopbsp_filter_translation', array(&$this, 'searchesHelp'));
                
                add_filter('dopbsp_filter_translation', array(&$this, 'searchesFrontEnd'));
            }

            /*
             * Search text.
             * 
             * @param lang (array): current translation
             * 
             * @return array with updated translation
             */
            function searches($lang){
                array_push($lang, array('key' => 'PARENT_SEARCHES',
                                        'parent' => '',
                                        'text' => 'Search'));
                
                array_push($lang, array('key' => 'SEARCHES_TITLE',
                                        'parent' => 'PARENT_SEARCHES',
                                        'text' => 'Search'));
                
                array_push($lang, array('key' => 'SEARCHES_CREATED_BY',
                                        'parent' => 'PARENT_SEARCHES',
                                        'text' => 'Created by'));
                array_push($lang, array('key' => 'SEARCHES_LOAD_SUCCESS',
                                        'parent' => 'PARENT_SEARCHES',
                                        'text' => 'Search list loaded.'));
                array_push($lang, array('key' => 'SEARCHES_NO_SEARCHES',
                                        'parent' => 'PARENT_SEARCHES',
                                        'text' => 'No searches. Click the above "plus" icon to add a new one.'));
                
                return $lang;
            }
            
            /*
             * Search - Search text.
             * 
             * @param lang (array): current translation
             * 
             * @return array with updated translation
             */
            function searchesSearch($lang){
                array_push($lang, array('key' => 'PARENT_SEARCHES_SEARCH',
                                        'parent' => '',
                                        'text' => 'Search'));
                
                array_push($lang, array('key' => 'SEARCHES_SEARCH_NAME',
                                        'parent' => 'PARENT_SEARCHES_SEARCH',
                                        'text' => 'Name'));
                
                array_push($lang, array('key' => 'SEARCHES_SEARCH_LOADED',
                                        'parent' => 'PARENT_SEARCHES_SEARCH',
                                        'text' => 'Search loaded.'));
                
                return $lang;
            }
            
            /*
             * Search - Add search text.
             * 
             * @param lang (array): current translation
             * 
             * @return array with updated translation
             */
            function searchesAddSearch($lang){
                array_push($lang, array('key' => 'PARENT_SEARCHES_ADD_SEARCH',
                                        'parent' => '',
                                        'text' => 'Search - Add search'));
                
                array_push($lang, array('key' => 'SEARCHES_ADD_SEARCH_NAME',
                                        'parent' => 'PARENT_SEARCHES_ADD_SEARCH',
                                        'text' => 'New search'));
                
                array_push($lang, array('key' => 'SEARCHES_ADD_SEARCH_SUBMIT',
                                        'parent' => 'PARENT_SEARCHES_ADD_SEARCH',
                                        'text' => 'Add search'));
                array_push($lang, array('key' => 'SEARCHES_ADD_SEARCH_ADDING',
                                        'parent' => 'PARENT_SEARCHES_ADD_SEARCH',
                                        'text' => 'Adding a new search ...'));
                array_push($lang, array('key' => 'SEARCHES_ADD_SEARCH_SUCCESS',
                                        'parent' => 'PARENT_SEARCHES_ADD_SEARCH',
                                        'text' => 'You have succesfully added a new search.'));
                
                return $lang;
            }
            
            /*
             * Search - Edit search text.
             * 
             * @param lang (array): current translation
             * 
             * @return array with updated translation
             */
            function searchesEditSearch($lang){
                array_push($lang, array('key' => 'PARENT_SEARCHES_EDIT_SEARCH',
                                        'parent' => '',
                                        'text' => 'Search - Edit search'));
                
                array_push($lang, array('key' => 'SEARCHES_EDIT_SEARCH',
                                        'parent' => 'PARENT_SEARCHES_EDIT_SEARCH',
                                        'text' => 'Edit search details'));
                array_push($lang, array('key' => 'SEARCHES_EDIT_SEARCH_SETTINGS',
                                        'parent' => 'PARENT_SEARCHES_EDIT_SEARCH',
                                        'text' => 'Edit search settings'));
                
                array_push($lang, array('key' => 'SEARCHES_EDIT_SEARCH_EXCLUDED_CALENDARS_DAYS',
                                        'parent' => 'PARENT_SEARCHES_EDIT_SEARCH',
                                        'text' => 'Exclude calendars from search [hours filters disabled]'));
                array_push($lang, array('key' => 'SEARCHES_EDIT_SEARCH_EXCLUDED_CALENDARS_HOURS',
                                        'parent' => 'PARENT_SEARCHES_EDIT_SEARCH',
                                        'text' => 'Exclude calendars from search [hours filters enabled]'));
                
                array_push($lang, array('key' => 'SEARCHES_EDIT_SEARCH_NO_CALENDARS',
                                        'parent' => 'PARENT_SEARCHES_EDIT_SEARCH',
                                        'text' => 'There are no calendars created. Go to <a href="%s">calendars</a> page to create one.'));
                
                return $lang;
            }
            
            /*
             * Search - Delete search text.
             * 
             * @param lang (array): current translation
             * 
             * @return array with updated translation
             */
            function searchesDeleteSearch($lang){
                array_push($lang, array('key' => 'PARENT_SEARCHES_DELETE_SEARCH',
                                        'parent' => '',
                                        'text' => 'Search - Delete search'));
                
                array_push($lang, array('key' => 'SEARCHES_DELETE_SEARCH_CONFIRMATION',
                                        'parent' => 'PARENT_SEARCHES_DELETE_SEARCH',
                                        'text' => 'Are you sure you want to delete this search?'));
                array_push($lang, array('key' => 'SEARCHES_DELETE_SEARCH_SUBMIT',
                                        'parent' => 'PARENT_SEARCHES_DELETE_SEARCH',
                                        'text' => 'Delete search'));
                array_push($lang, array('key' => 'SEARCHES_DELETE_SEARCH_DELETING',
                                        'parent' => 'PARENT_SEARCHES_DELETE_SEARCH',
                                        'text' => 'Deleting search ...'));
                array_push($lang, array('key' => 'SEARCHES_DELETE_SEARCH_SUCCESS',
                                        'parent' => 'PARENT_SEARCHES_DELETE_SEARCH',
                                        'text' => 'You have succesfully deleted the search.'));
                
                return $lang;
            }
            
            /*
             * Search - Help text.
             * 
             * @param lang (array): current translation
             * 
             * @return array with updated translation
             */
            function searchesHelp($lang){
                array_push($lang, array('key' => 'PARENT_SEARCHES_HELP',
                                        'parent' => '',
                                        'text' => 'Search - Help'));
                
                array_push($lang, array('key' => 'SEARCHES_HELP',
                                        'parent' => 'PARENT_SEARCHES_HELP',
                                        'text' => 'Click on a search item to open the editing area.'));
                array_push($lang, array('key' => 'SEARCHES_ADD_SEARCH_HELP',
                                        'parent' => 'PARENT_SEARCHES_HELP',
                                        'text' => 'Click on the "plus" icon to add a search.'));
                
                array_push($lang, array('key' => 'SEARCHES_EDIT_SEARCH_HELP',
                                        'parent' => 'PARENT_SEARCHES_HELP',
                                        'text' => 'Click on the "search" icon to edit search details.'));
                array_push($lang, array('key' => 'SEARCHES_EDIT_SEARCH_SETTINGS_HELP',
                                        'parent' => 'PARENT_SEARCHES_HELP',
                                        'text' => 'Click on the "gear" icon to edit search settings.'));
                array_push($lang, array('key' => 'SEARCHES_EDIT_SEARCH_DELETE_HELP',
                                        'parent' => 'PARENT_SEARCHES_HELP',
                                        'text' => 'Click the "trash" icon to delete the search.'));
                array_push($lang, array('key' => 'SEARCHES_EDIT_SEARCH_EXCLUDED_CALENDARS_HELP',
                                        'parent' => 'PARENT_SEARCHES_HELP',
                                        'text' => 'If hours filters are enabled only calendars that have availability set for hours are included in search, else only calendar that have availability set for days are included.'));
                
                array_push($lang, array('key' => 'SEARCHES_SEARCH_NAME_HELP',
                                        'parent' => 'PARENT_SEARCHES_HELP',
                                        'text' => 'Change search name.'));
                
                return $lang;
            }
            
            /*
             * Search front end text.
             * 
             * @param lang (array): current translation
             * 
             * @return array with updated translation
             */
            function searchesFrontEnd($lang){
                array_push($lang, array('key' => 'PARENT_SEARCH_FRONT_END',
                                        'parent' => '',
                                        'text' => 'Search - Front end'));
                     
                array_push($lang, array('key' => 'SEARCH_FRONT_END_TITLE',
                                        'parent' => 'PARENT_SEARCH_FRONT_END',
                                        'text' => 'Search'));
                     
                array_push($lang, array('key' => 'SEARCH_FRONT_END_CHECK_IN',
                                        'parent' => 'PARENT_SEARCH_FRONT_END',
                                        'text' => 'Check in',
                                        'de' => 'Anreise',
                                        'nl' => 'Check in',
                                        'fr' => 'Arrivée',
                                        'pl' => 'Przyjazd'));
                array_push($lang, array('key' => 'SEARCH_FRONT_END_CHECK_OUT',
                                        'parent' => 'PARENT_SEARCH_FRONT_END',
                                        'text' => 'Check out',
                                        'de' => 'Abreise',
                                        'nl' => 'Check uit',
                                        'fr' => 'Départ',
                                        'pl' => 'Wyjazd'));
                array_push($lang, array('key' => 'SEARCH_FRONT_END_START_HOUR',
                                        'parent' => 'PARENT_SEARCH_FRONT_END',
                                        'text' => 'Start at',
                                        'de' => 'Start um',
                                        'nl' => 'Start op',
                                        'fr' => 'Arrivée à',
                                        'pl' => 'Rozpoczęcie')); 
                array_push($lang, array('key' => 'SEARCH_FRONT_END_END_HOUR',
                                        'parent' => 'PARENT_SEARCH_FRONT_END',
                                        'text' => 'Finish at',
                                        'de' => 'Ende um',
                                        'nl' => 'Eindigd op',
                                        'fr' => 'Départ à',
                                        'pl' => 'Zakończenie'));
                array_push($lang, array('key' => 'SEARCH_FRONT_END_NO_ITEMS',
                                        'parent' => 'PARENT_SEARCH_FRONT_END',
                                        'text' => 'No book items',
                                        'de' => 'No book items',
                                        'nl' => '# Accomodaties',
                                        'fr' => 'Aucun élément de réservation',
                                        'pl' => 'Brak rezerwacji'));
                /*
                 * No data.
                 */
                array_push($lang, array('key' => 'SEARCH_FRONT_END_NO_AVAILABILITY',
                                        'parent' => 'PARENT_SEARCH_FRONT_END',
                                        'text' => 'Nothing available.'));
                array_push($lang, array('key' => 'SEARCH_FRONT_END_NO_SERVICES_AVAILABLE',
                                        'parent' => 'PARENT_SEARCH_FRONT_END',
                                        'text' => 'There are no services available for the period you selected.',
                                        'de' => 'There are no services available for the period you selected.',
                                        'nl' => 'Er zijn geen er zijn geen diensten beschikbaar voor de periode die u hebt geselecteerd.',
                                        'fr' => 'Il n<<single-quote>>y a pas de services disponibles pour la période que vous avez sélectionné.',
                                        'pl' => 'W wybranych terminie nie posiadamy wolnych miejsc.'));
                array_push($lang, array('key' => 'SEARCH_FRONT_END_NO_SERVICES_AVAILABLE_SPLIT_GROUP',
                                        'parent' => 'PARENT_SEARCH_FRONT_END',
                                        'text' => 'You cannot add divided groups to a reservation.'));
                /*
                 * Sort
                 */
                array_push($lang, array('key' => 'SEARCH_FRONT_END_SORT_TITLE',
                                        'parent' => 'PARENT_SEARCH_FRONT_END',
                                        'text' => 'Sort by'));
                array_push($lang, array('key' => 'SEARCH_FRONT_END_SORT_NAME',
                                        'parent' => 'PARENT_SEARCH_FRONT_END',
                                        'text' => 'Name'));
                array_push($lang, array('key' => 'SEARCH_FRONT_END_SORT_PRICE',
                                        'parent' => 'PARENT_SEARCH_FRONT_END',
                                        'text' => 'Price'));
                array_push($lang, array('key' => 'SEARCH_FRONT_END_SORT_ASC',
                                        'parent' => 'PARENT_SEARCH_FRONT_END',
                                        'text' => 'Ascending'));
                array_push($lang, array('key' => 'SEARCH_FRONT_END_SORT_DESC',
                                        'parent' => 'PARENT_SEARCH_FRONT_END',
                                        'text' => 'Descending'));
                /*
                 * View
                 */
                array_push($lang, array('key' => 'SEARCH_FRONT_END_VIEW_GRID',
                                        'parent' => 'PARENT_SEARCH_FRONT_END',
                                        'text' => 'Grid view'));
                array_push($lang, array('key' => 'SEARCH_FRONT_END_VIEW_LIST',
                                        'parent' => 'PARENT_SEARCH_FRONT_END',
                                        'text' => 'List view'));
                array_push($lang, array('key' => 'SEARCH_FRONT_END_VIEW_MAP',
                                        'parent' => 'PARENT_SEARCH_FRONT_END',
                                        'text' => 'Map view'));
                /*
                 * Results
                 */
                array_push($lang, array('key' => 'SEARCH_FRONT_END_RESULTS_PRICE',
                                        'parent' => 'PARENT_SEARCH_FRONT_END',
                                        'text' => 'Start at %s'));
                array_push($lang, array('key' => 'SEARCH_FRONT_END_RESULTS_VIEW',
                                        'parent' => 'PARENT_SEARCH_FRONT_END',
                                        'text' => 'View'));
                
                return $lang;
            }
        }
    }