/*
* Title                   : Booking System PRO (WordPress Plugin)
* Version                 : 2.0
* File                    : assets/js/reservations/backend-reservations.js
* File Version            : 1.0.3
* Created / Last Modified : 23 September 2014
* Author                  : Dot on Paper
* Copyright               : © 2012 Dot on Paper
* Website                 : http://www.dotonpaper.net
* Description             : Booking System PRO back end reservations JavaScript class.
*/

var DOPBSPReservations = new function(){
    'use strict';
    
    /*
     * Private variables.
     */
    var $ = jQuery.noConflict();
        
    /*
     * Constructor
     */
    this.DOPBSPReservations = function(){
    };
    
    /*
     * Display reservations.
     */
    this.display = function(){
        var calendarID = $('#DOPBSP-calendar-ID').val();
        
        $('.DOPBSP-admin .dopbsp-main').css('display', 'block');  
        
        if (calendarID.indexOf(',') !== -1){
            $('.DOPBSP-admin .dopbsp-main .dopbsp-button.dopbsp-reservations-add-button').addClass('dopbsp-disabled');
            $('.DOPBSP-admin .dopbsp-main .dopbsp-button.dopbsp-reservations-calendar-button').addClass('dopbsp-disabled');
            DOPPrototypes.setCookie('DOPBSP_reservations_calendar', '', 60);
        }
        else{
            $('.DOPBSP-admin .dopbsp-main .dopbsp-button.dopbsp-reservations-add-button').removeClass('dopbsp-disabled');
            $('.DOPBSP-admin .dopbsp-main .dopbsp-button.dopbsp-reservations-calendar-button').removeClass('dopbsp-disabled');
            DOPPrototypes.setCookie('DOPBSP_reservations_calendar', calendarID, 60);
        }
        
        if (calendarID.indexOf(',') !== -1){
            DOPBSPReservationsList.display();
        }
        else if ($('.DOPBSP-admin .dopbsp-main .dopbsp-button.dopbsp-reservations-add-button').hasClass('dopbsp-selected')){
            DOPBSPReservationsAdd.display();
        }
        else if ($('.DOPBSP-admin .dopbsp-main .dopbsp-button.dopbsp-reservations-calendar-button').hasClass('dopbsp-selected')){
            DOPBSPReservationsCalendar.display();
        }
        else if ($('.DOPBSP-admin .dopbsp-main .dopbsp-button.dopbsp-reservations-list-button').hasClass('dopbsp-selected')){
            DOPBSPReservationsList.display();
        }
        else{
            if (DOPPrototypes.getCookie('DOPBSP_reservations_view') === 'calendar'){
                DOPBSPReservationsCalendar.display();
            }
            else{
                DOPBSPReservationsList.display();
            }
        }
    };
    
    return this.DOPBSPReservations();
};